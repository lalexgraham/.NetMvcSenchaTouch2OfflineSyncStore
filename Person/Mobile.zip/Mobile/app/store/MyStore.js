Ext.define('MyApp.store.MyStore', {
    extend: 'Ext.ux.OfflineSyncStore',
    model: 'MyApp.model.PersonModel',
    config: {
        storeId: 'MyStore',
        localProxy: {
            type: 'localstorage',
            id: 'offline-sync-store'
        },
        serverProxy: {
            type: 'ajax',
            api: {
                read: '../Person',
                create: '../Person/Create'
            },
            reader: {
                type: 'json',
                rootProperty: 'rows'
            },
            writer: {
                allowSingle: false
            }
        }
    }	
});