
Ext.Loader.setConfig({
    enabled: true
});

Ext.application({
	name: 'MyApp',
	models: [
      	'PersonModel'
    ],
    views: [
        'MyTabPanel'
    ],
    stores: [
       'MyStore'
    ],/*
    controllers: [
        'MyController'
    ],*/
	
    launch: function() {
		/*var offlineSyncStore = Ext.create('Ext.ux.OfflineSyncStore', {
                model: 'MyApp.model.PersonModel',

                localProxy: {
                    type: 'localstorage',
                    id: 'offline-sync-store'
                },

                serverProxy: {
                    type: 'ajax',
                    api: {
                        read: '../Person',
                        create: '../Person/Create'
                    },
                    reader: {
                        type: 'json',
                        rootProperty: 'rows'
                    },
                    writer: {
                        allowSingle: false
                    }
                }
            });
*/
            var offlineSyncStore = Ext.getStore('MyStore');
                       
            offlineSyncStore.loadServer(function(){

                var person = Ext.create('MyApp.model.PersonModel', {
                    FirstName: 'Joe1',
                    LastName: 'Bloggs1',
                    Email: 'joe@swarmonline1.com'
                });

                offlineSyncStore.add(person);
                
                offlineSyncStore.sync();

                //offlineSyncStore.syncServer();
            });

            console.log(offlineSyncStore);
    }

});
